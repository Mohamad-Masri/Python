RBOX_DEBUG=0

if [ $RBOX_DEBUG != 1 ]; then
	whiptail --title "R-BOX Message Of The Week" --msgbox "Chicken Nuggets" 14 60
fi