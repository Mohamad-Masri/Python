# Account-Storage
A basic GUI that allows you to store your emails, password and account information.

# Run in Gitpod

You can also run Account-Storage in Gitpod, a free online dev environment for GitHub:

If you're intersted in a paid subscription with GitPod use the coupon code: **TECHWITHTIM19**

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/techwithtim/Account-Storage/blob/master/main.py)

Please Note: The GUI is a little glithcy in GitPod. For best results expand the VNC window to be full screen.
