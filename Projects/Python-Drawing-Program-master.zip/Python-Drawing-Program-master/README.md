# Python-Drawing-Program
A python program similar to Microsoft paint. It allows you to use a variety of drawing tools on a pixel grid to create drawings. It features the ability to save and load work created within the program.

# Requirements
- Python 3.x
- TKinter
- Pygame

# Run in Gitpod

You can also run Python-Drawing-Program in Gitpod, a free online dev environment for GitHub:

If you're intersted in a paid subscription with GitPod use the coupon code: **TECHWITHTIM19**

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/techwithtim/Python-Drawing-Program/blob/master/main.py)

Please Note: The GUI is a little glithcy in GitPod. For best results expand the VNC window to be full screen.
