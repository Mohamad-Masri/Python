echo -n "IP/WEBSITE: "
read host
echo -n "What Port To Scan: "
read port
python PortScanner.py -T $host -p $port