# R-Box

# About The Coder
There is only one person working on R-BOX and I still go to school so it will be hard to update this program on a regular time, I do this just because I want to be a pen-tester when I am legally allowed to work. I really enjoy coding and please dont leech or sell this program.

# What is R-BOX
R-BOX is a python frame-work that is made for linux and if i get enough support I will make a version for windows, with this program at this moment you can sql inject automatically, sniffing, spoofing and explotation tools. If you wanna help just tell me.


# Updates
If there is an update it will be uncommon because I will add to this program when I want to 
